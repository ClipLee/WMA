# Policz monety na tacy - 15p

Dostępne dane `tray1.jpg` … `tray8.jpg`, wszystkie zadania wykonać dla wszystkich zdjęć.

### Zad. 1 - 5p

Odnajdź na obrazach wszystkie monety 5 zł i 5 gr oraz oznacz które są które.

### Zad. 2 - 3p

Oblicz powierzchnię monet i przelicz ile jest monet 5 zł a ile 5 gr.

### Zad. 3 - 5p

Określ krawędzie tacy i wylicz jej powierzchnię. O ile mniejsze są monety 5 zł w stosunku do tacy?

### Zad. 4 - 2p

Oblicz jaka kwota leży na tacy a jaka poza nią.